package com.Main.dao;

import org.springframework.data.jpa.repository.JpaRepository;



import com.Main.entity.MttrAndMtbfCalulation;

public interface MttrAndMtbfCalulationDao extends JpaRepository< MttrAndMtbfCalulation, Long>{

}
