package com.Main.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Main.entity.BreakDownAnlysis;

public interface BreakDownAnlysisDao extends JpaRepository<BreakDownAnlysis, Long>{

}
