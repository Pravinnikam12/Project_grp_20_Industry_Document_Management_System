package com.Main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectIdms1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
