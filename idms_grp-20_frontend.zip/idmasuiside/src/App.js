//import { Route, Routes } from 'react-router';
import { BrowserRouter as Router,Routes,Route} from "react-router-dom";

import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import Admin from './components/Admin';
import Audit from './components/Audit';
import Maintainance from './components/Maintainance';
//import AttV from './components/AttV';
import MachineList from './components/MachineList';
import Break from './components/Break';
import Consumption from './components/Consumption';
import MachineDetails from './components/MachineDetails';
import AddMachineDetails from './components/AddMachineDetails';
import NotFound from "./components/NotFound";
import MttrAndMtbf from './components/MttrAndMtbf';
import AddMttrAndMtbf from './components/AddMttrAndMtbf';
import AddAttendance from "./components/AddAttendance";
import EmpAttendance from "./components/EmpAttendance";
import BreakDown from "./components/BreakDown";
import AddBreakdown from "./components/AddBreakdown";


function App() {
  return (
    
    
      <Routes>
        
        <Route path="/" element={<Home />}  />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register/>} />
        <Route path="/admin" element={<Admin/>} />
        <Route path="/audit" element={<Audit/>} />
        <Route path="/maintainance" element={<Maintainance/>} />

        <Route path="/empAttendance" element={<EmpAttendance/>} />
        <Route path="/addAttendance" element={<AddAttendance/>} />
        <Route  path="/Attendances/edit/:id" element={<AddAttendance/>} />

        
        <Route path="/machineList" element={<MachineList/>} />  
        <Route path="/machineDetails" element={<MachineDetails/>} /> 
        <Route  path="/addMachineDetails" element={<AddMachineDetails/>} />
  
        <Route  path="/mttrAndMtbf" element={<MttrAndMtbf/>} />
        <Route  path="/addMttrAndMtbf" element={<AddMttrAndMtbf/>} />
        <Route  path="/MttrAndMtbfCalulations/Medit/:sr_no" element={<AddMttrAndMtbf/>} />

       
    

        <Route  path="/breakDown" element={<BreakDown/>} />
        <Route  path="/addBreakdown" element={<AddBreakdown/>} />
         <Route  path="/BreakDownAnlysiss/Bkedit/:sr_no" element={<AddBreakdown/>} /> 
        <Route  path="*" element={<NotFound/>} />

        <Route path="/break" element={<Break/>} /> 
        <Route path="/consumption" element={<Consumption/>} />  
        
      </Routes>
    
    
  );
}

export default App;




// <Route  path="/ListOfMachiness/Mdedit/:sr_no" element={<AddMachineDetails/>} />
